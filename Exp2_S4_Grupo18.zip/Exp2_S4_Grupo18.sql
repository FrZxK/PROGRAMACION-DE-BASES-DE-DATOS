
-- ================================================================================
-- CASO 1: PROCESAMIENTO DE PUNTOS DEL PROGRAMA "C�RCULO ALL THE BEST"
-- ================================================================================

DECLARE
    -- ============================================================================
    -- 1: DECLARACI�N DE VARIABLES BIND
    -- ============================================================================
    
    v_tramo1_min NUMBER := 500000;
    v_tramo1_max NUMBER := 700000;
    
    v_tramo2_min NUMBER := 700001;
    v_tramo2_max NUMBER := 900000;
    
    v_tramo3_min NUMBER := 900001;
    
    -- ============================================================================
    -- 2: DECLARACI�N DE VARRAY PARA PUNTOS
    -- ============================================================================
    
    TYPE t_puntos IS VARRAY(4) OF NUMBER;
    v_arr_puntos t_puntos := t_puntos(250, 300, 550, 700);
    
    -- ============================================================================
    -- 3: DECLARACI�N DE REGISTROS PL/SQL
    -- ============================================================================
    -- Registro para almacenar informaci�n resumida por mes
    TYPE t_resumen_mes IS RECORD (
        mes_anio VARCHAR2(10),
        monto_total_compras NUMBER := 0,
        total_puntos_compras NUMBER := 0,
        monto_total_avances NUMBER := 0,
        total_puntos_avances NUMBER := 0,
        monto_total_savances NUMBER := 0,
        total_puntos_savances NUMBER := 0
    );
    
    v_resumen t_resumen_mes;
    
    -- Registro para informaci�n detallada de cada transacci�n
    TYPE t_detalle_transac IS RECORD (
        numrun NUMBER,
        dvrun VARCHAR2(1),
        nro_tarjeta VARCHAR2(20),
        nro_transaccion VARCHAR2(10),
        fecha_transaccion DATE,
        tipo_transaccion VARCHAR2(50),
        monto_transaccion NUMBER,
        PUNTOS_ALLTHEBEST NUMBER
    );
    
    v_detalle t_detalle_transac;
    
    -- ============================================================================
    -- 4: VARIABLES AUXILIARES
    -- ============================================================================
    v_anio_anterior NUMBER;             
    v_monto_anual_cliente NUMBER;      
    v_puntos_calculados NUMBER;       
    v_puntos_base NUMBER;               
    v_puntos_extras NUMBER := 0;        
    v_tipo_cliente VARCHAR2(50);       
    v_mes_actual VARCHAR2(10);         
    v_mes_anterior VARCHAR2(10) := '';  
    
    -- ============================================================================
    -- 5: DECLARACI�N DE VARIABLE DE CURSOR (REF CURSOR)
    -- ============================================================================
    
    TYPE t_cursor_resumen IS REF CURSOR;
    c_resumen_mensual t_cursor_resumen;
    
    -- ============================================================================
    -- 6: DECLARACI�N DE CURSOR EXPL�CITO CON PAR�METRO
    -- ============================================================================
    
    CURSOR c_detalle_transacciones(p_mes_anio VARCHAR2) IS
        SELECT 
            c.numrun,
            c.dvrun,
            tc.nro_tarjeta,
            t.nro_transaccion,
            t.fecha_transaccion,
            tp.nombre_tptran_tarjeta,
            t.monto_total_transaccion,
            tcli.nombre_tipo_cliente
        FROM 
            TRANSACCION_TARJETA_CLIENTE t
            INNER JOIN TARJETA_CLIENTE tc ON t.nro_tarjeta = tc.nro_tarjeta
            INNER JOIN CLIENTE c ON tc.numrun = c.numrun
            INNER JOIN TIPO_TRANSACCION_TARJETA tp ON t.cod_tptran_tarjeta = tp.cod_tptran_tarjeta
            INNER JOIN TIPO_CLIENTE tcli ON c.cod_tipo_cliente = tcli.cod_tipo_cliente
        WHERE 
            TO_CHAR(t.fecha_transaccion, 'MMYYYY') = p_mes_anio
        ORDER BY 
            t.fecha_transaccion,
            c.numrun,
            t.nro_transaccion;

BEGIN
    -- ============================================================================
    -- 7: INICIALIZACI�N Y LIMPIEZA DE TABLAS
    -- ============================================================================
    
    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('CASO 1: PROCESAMIENTO DE PUNTOS - PROGRAMA C�RCULO ALL THE BEST');
    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('Inicio del proceso: ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Calcular a�o anterior din�micamente
    v_anio_anterior := EXTRACT(YEAR FROM SYSDATE) - 1;
    
    DBMS_OUTPUT.PUT_LINE('Procesando transacciones del a�o: ' || v_anio_anterior);
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Truncar tablas para permitir m�ltiples ejecuciones
    EXECUTE IMMEDIATE 'TRUNCATE TABLE DETALLE_PUNTOS_TARJETA_CATB';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE RESUMEN_PUNTOS_TARJETA_CATB';
    
    DBMS_OUTPUT.PUT_LINE('Tablas truncadas exitosamente');
    DBMS_OUTPUT.PUT_LINE('');
    
    -- ============================================================================
    -- 8: APERTURA DEL CURSOR PARA RESUMEN MENSUAL
    -- ===========================================================================
    
    OPEN c_resumen_mensual FOR
        SELECT DISTINCT TO_CHAR(fecha_transaccion, 'MMYYYY') AS mes_anio
        FROM TRANSACCION_TARJETA_CLIENTE
        WHERE EXTRACT(YEAR FROM fecha_transaccion) = v_anio_anterior
        ORDER BY mes_anio;
    
    DBMS_OUTPUT.PUT_LINE('Procesando meses del a�o ' || v_anio_anterior || '...');
    DBMS_OUTPUT.PUT_LINE('');
    
    -- ============================================================================
    -- 9: BUCLE PRINCIPAL - PROCESAMIENTO POR MES
    -- ============================================================================
    
    LOOP
        -- Obtener el siguiente mes a procesar
        FETCH c_resumen_mensual INTO v_mes_actual;
        EXIT WHEN c_resumen_mensual%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('--- Procesando mes: ' || v_mes_actual || ' ---');
        
        -- Inicializar registro de resumen para el mes actual
        v_resumen.mes_anio := v_mes_actual;
        v_resumen.monto_total_compras := 0;
        v_resumen.total_puntos_compras := 0;
        v_resumen.monto_total_avances := 0;
        v_resumen.total_puntos_avances := 0;
        v_resumen.monto_total_savances := 0;
        v_resumen.total_puntos_savances := 0;
        
        -- ========================================================================
        -- 10: APERTURA DEL CURSOR CON PAR�METRO
        -- ========================================================================
        -- Se abre el cursor expl�cito pasando el mes actual como par�metro
        
        FOR reg_transaccion IN c_detalle_transacciones(v_mes_actual) LOOP
            
            v_puntos_base := 0;
            v_puntos_extras := 0;
            v_puntos_calculados := 0;
            v_tipo_cliente := reg_transaccion.nombre_tipo_cliente;
            
            -- ====================================================================
            -- 11: C�LCULO DE PUNTOS BASE
            -- ====================================================================
            
            v_puntos_base := TRUNC(reg_transaccion.monto_total_transaccion / 100000) * v_arr_puntos(1);
            
            -- ====================================================================
            -- 12: C�LCULO DE PUNTOS EXTRAS PARA TIPOS ESPECIALES
            -- ====================================================================
            
            IF v_tipo_cliente IN ('Dueña de Casa', 'Pensionado y Tercera Edad') THEN
                
                SELECT NVL(SUM(t.monto_total_transaccion), 0)
                INTO v_monto_anual_cliente
                FROM TRANSACCION_TARJETA_CLIENTE t
                INNER JOIN TARJETA_CLIENTE tc ON t.nro_tarjeta = tc.nro_tarjeta
                WHERE tc.numrun = reg_transaccion.numrun
                AND EXTRACT(YEAR FROM t.fecha_transaccion) = v_anio_anterior;
                
                -- Determinar tramo y calcular puntos extras usando estructura condicional
                IF v_monto_anual_cliente >= v_tramo3_min THEN
                    v_puntos_extras := TRUNC(reg_transaccion.monto_total_transaccion / 100000) * v_arr_puntos(4);
                    
                ELSIF v_monto_anual_cliente >= v_tramo2_min AND v_monto_anual_cliente <= v_tramo2_max THEN
                    v_puntos_extras := TRUNC(reg_transaccion.monto_total_transaccion / 100000) * v_arr_puntos(3);
                    
                ELSIF v_monto_anual_cliente >= v_tramo1_min AND v_monto_anual_cliente <= v_tramo1_max THEN
                    v_puntos_extras := TRUNC(reg_transaccion.monto_total_transaccion / 100000) * v_arr_puntos(2);
                    
                END IF;
                
            END IF;
            
            -- Calcular total de puntos (base + extras)
            v_puntos_calculados := v_puntos_base + v_puntos_extras;
            
            -- ====================================================================
            -- 13: INSERCI�N EN TABLA DE DETALLE
            -- ====================================================================
            
            INSERT INTO DETALLE_PUNTOS_TARJETA_CATB (
                numrun,
                dvrun,
                nro_tarjeta,
                nro_transaccion,
                fecha_transaccion,
                tipo_transaccion,
                monto_transaccion,
                PUNTOS_ALLTHEBEST
            ) VALUES (
                reg_transaccion.numrun,
                reg_transaccion.dvrun,
                reg_transaccion.nro_tarjeta,
                reg_transaccion.nro_transaccion,
                reg_transaccion.fecha_transaccion,
                reg_transaccion.nombre_tptran_tarjeta,
                reg_transaccion.monto_total_transaccion,
                v_puntos_calculados
            );
            
            -- ====================================================================
            -- 14: ACUMULACI�N PARA RESUMEN MENSUAL
            -- ====================================================================
            
            IF reg_transaccion.nombre_tptran_tarjeta LIKE '%Compra%' THEN
                v_resumen.monto_total_compras := v_resumen.monto_total_compras + reg_transaccion.monto_total_transaccion;
                v_resumen.total_puntos_compras := v_resumen.total_puntos_compras + v_puntos_calculados;
                
            ELSIF reg_transaccion.nombre_tptran_tarjeta LIKE '%Súper Avance%' OR 
                  reg_transaccion.nombre_tptran_tarjeta LIKE '%Super Avance%' THEN
                v_resumen.monto_total_savances := v_resumen.monto_total_savances + reg_transaccion.monto_total_transaccion;
                v_resumen.total_puntos_savances := v_resumen.total_puntos_savances + v_puntos_calculados;
                
            ELSIF reg_transaccion.nombre_tptran_tarjeta LIKE '%Avance%' THEN
                v_resumen.monto_total_avances := v_resumen.monto_total_avances + reg_transaccion.monto_total_transaccion;
                v_resumen.total_puntos_avances := v_resumen.total_puntos_avances + v_puntos_calculados;
                
            END IF;
            
        END LOOP;
        
        -- ========================================================================
        -- 15: INSERCI�N DEL RESUMEN MENSUAL
        -- ========================================================================
        
        INSERT INTO RESUMEN_PUNTOS_TARJETA_CATB (
            mes_anno,
            monto_total_compras,
            total_puntos_compras,
            monto_total_avances,
            total_puntos_avances,
            monto_total_savances,
            total_puntos_savances
        ) VALUES (
            v_resumen.mes_anio,
            v_resumen.monto_total_compras,
            v_resumen.total_puntos_compras,
            v_resumen.monto_total_avances,
            v_resumen.total_puntos_avances,
            v_resumen.monto_total_savances,
            v_resumen.total_puntos_savances
        );
        
        DBMS_OUTPUT.PUT_LINE('  Transacciones procesadas para el mes ' || v_mes_actual);
        
    END LOOP;
    
    -- Cerrar el cursor REF CURSOR
    CLOSE c_resumen_mensual;
    
    -- ============================================================================
    -- 16: CONFIRMACI�N DE TRANSACCI�N
    -- ============================================================================
    
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('Proceso completado exitosamente');
    DBMS_OUTPUT.PUT_LINE('Fin del proceso: ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('');

EXCEPTION
    -- ============================================================================
    -- 17: MANEJO DE EXCEPCIONES
    -- ============================================================================
    WHEN OTHERS THEN
        -- Revertir cambios en caso de error
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: ' || SQLERRM);
        DBMS_OUTPUT.PUT_LINE('Transacci�n revertida');
        RAISE;
END;
/


-- ================================================================================
-- CASO 2: PROCESAMIENTO DE APORTES SBIF
-- ================================================================================

DECLARE
    -- Registro para resumen mensual por tipo
    TYPE t_resumen_sbif IS RECORD (
        mes_anno VARCHAR2(10),
        tipo_transaccion VARCHAR2(50),
        monto_total_transacciones NUMBER := 0,
        aporte_total_abif NUMBER := 0
    );
    v_resumen_sbif t_resumen_sbif;
    
    -- Variables auxiliares
    v_anio_anterior NUMBER;
    v_aporte_calculado NUMBER := 0;
    v_porcentaje_aporte NUMBER := 0;
    v_contador_registros NUMBER := 0;
    
    -- Cursor expl�cito para resumen mensual
    CURSOR c_resumen_mensual_sbif IS
        SELECT 
            TO_CHAR(t.fecha_transaccion, 'MMYYYY') AS mes_anno,
            tp.nombre_tptran_tarjeta,
            SUM(t.monto_total_transaccion) AS monto_total
        FROM 
            TRANSACCION_TARJETA_CLIENTE t
            INNER JOIN TIPO_TRANSACCION_TARJETA tp ON t.cod_tptran_tarjeta = tp.cod_tptran_tarjeta
        WHERE 
            EXTRACT(YEAR FROM t.fecha_transaccion) = EXTRACT(YEAR FROM SYSDATE) - 1
            AND (tp.nombre_tptran_tarjeta LIKE '%Avance en Efectivo%' OR 
                 tp.nombre_tptran_tarjeta LIKE '%Súper Avance en Efectivo%' OR
                 tp.nombre_tptran_tarjeta LIKE '%Super Avance en Efectivo%')
        GROUP BY 
            TO_CHAR(t.fecha_transaccion, 'MMYYYY'),
            tp.nombre_tptran_tarjeta
        ORDER BY 
            mes_anno,
            tp.nombre_tptran_tarjeta;
    
    -- Cursor expl�cito con par�metros para detalle
    CURSOR c_detalle_sbif(p_mes_anno VARCHAR2, p_tipo_transaccion VARCHAR2) IS
        SELECT 
            c.numrun,
            c.dvrun,
            tc.nro_tarjeta,
            t.nro_transaccion,
            t.fecha_transaccion,
            tp.nombre_tptran_tarjeta,
            t.monto_total_transaccion
        FROM 
            TRANSACCION_TARJETA_CLIENTE t
            INNER JOIN TARJETA_CLIENTE tc ON t.nro_tarjeta = tc.nro_tarjeta
            INNER JOIN CLIENTE c ON tc.numrun = c.numrun
            INNER JOIN TIPO_TRANSACCION_TARJETA tp ON t.cod_tptran_tarjeta = tp.cod_tptran_tarjeta
        WHERE 
            TO_CHAR(t.fecha_transaccion, 'MMYYYY') = p_mes_anno
            AND tp.nombre_tptran_tarjeta = p_tipo_transaccion
        ORDER BY 
            t.fecha_transaccion,
            c.numrun;

BEGIN
    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('CASO 2: PROCESAMIENTO DE APORTES SBIF');
    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('Inicio: ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));
    
    -- Calcular a�o anterior din�micamente
    v_anio_anterior := EXTRACT(YEAR FROM SYSDATE) - 1;
    DBMS_OUTPUT.PUT_LINE('Procesando avances del a�o: ' || v_anio_anterior);
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Truncar tablas
    EXECUTE IMMEDIATE 'TRUNCATE TABLE DETALLE_APORTE_SBIF';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE RESUMEN_APORTE_SBIF';
    DBMS_OUTPUT.PUT_LINE('Tablas truncadas correctamente');
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Procesar cada combinaci�n mes-tipo
    FOR reg_resumen IN c_resumen_mensual_sbif LOOP
        
        DBMS_OUTPUT.PUT_LINE('Procesando: ' || reg_resumen.mes_anno || ' - ' || reg_resumen.nombre_tptran_tarjeta);
        
        -- Inicializar resumen
        v_resumen_sbif.mes_anno := reg_resumen.mes_anno;
        v_resumen_sbif.tipo_transaccion := reg_resumen.nombre_tptran_tarjeta;
        v_resumen_sbif.monto_total_transacciones := 0;
        v_resumen_sbif.aporte_total_abif := 0;
        
        -- Procesar detalle usando cursor con par�metros
        FOR reg_detalle IN c_detalle_sbif(reg_resumen.mes_anno, reg_resumen.nombre_tptran_tarjeta) LOOP
            
            v_aporte_calculado := 0;
            v_porcentaje_aporte := 0;
            
            -- Obtener porcentaje de aporte seg�n el monto de la transacci�n
            SELECT tas.porc_aporte_sbif
            INTO v_porcentaje_aporte
            FROM TRAMO_APORTE_SBIF tas
            WHERE reg_detalle.monto_total_transaccion  >= tas.tramo_inf_av_sav
            AND reg_detalle.monto_total_transaccion  <= tas.tramo_sup_av_sav;
            
            -- Calcular aporte en PL/SQL
            v_aporte_calculado := ROUND(reg_detalle.monto_total_transaccion  * (v_porcentaje_aporte / 100));
            
            -- Insertar en tabla de detalle
            INSERT INTO DETALLE_APORTE_SBIF (
                numrun,
                dvrun,
                nro_tarjeta,
                nro_transaccion,
                fecha_transaccion,
                tipo_transaccion,
                monto_transaccion,
                aporte_sbif
            ) VALUES (
                reg_detalle.numrun,
                reg_detalle.dvrun,
                reg_detalle.nro_tarjeta,
                reg_detalle.nro_transaccion,
                reg_detalle.fecha_transaccion,
                reg_detalle.nombre_tptran_tarjeta,
                reg_detalle.monto_total_transaccion ,
                v_aporte_calculado
            );
            
            -- Acumular para resumen
            v_resumen_sbif.monto_total_transacciones := v_resumen_sbif.monto_total_transacciones + reg_detalle.monto_total_transaccion ;
            v_resumen_sbif.aporte_total_abif := v_resumen_sbif.aporte_total_abif + v_aporte_calculado;
            
            v_contador_registros := v_contador_registros + 1;
            
        END LOOP;
        
        -- Insertar resumen mensual
        INSERT INTO RESUMEN_APORTE_SBIF (
            mes_anno,
            tipo_transaccion,
            monto_total_transacciones,
            aporte_total_abif
        ) VALUES (
            v_resumen_sbif.mes_anno,
            v_resumen_sbif.tipo_transaccion,
            v_resumen_sbif.monto_total_transacciones,
            v_resumen_sbif.aporte_total_abif
        );
        
        DBMS_OUTPUT.PUT_LINE('  Registros procesados: ' || v_contador_registros);
        v_contador_registros := 0;
        
    END LOOP;
    
    -- Confirmar transacci�n
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('Proceso completado exitosamente');
    DBMS_OUTPUT.PUT_LINE('Fin: ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: No se encontr� tramo de aporte para el monto');
        RAISE;
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: ' || SQLERRM);
        RAISE;
END;
/
